#ifndef MESSAGEDEFINE_H
#define MESSAGEDEFINE_H

enum {
    MESSAGE_TEST = 1000,
};

#endif