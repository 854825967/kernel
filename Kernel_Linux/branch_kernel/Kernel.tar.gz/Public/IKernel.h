#ifndef _IKERNEL_H_
#define _IKERNEL_H_

#include "ComDefine.h"
#include "EventDefine.h"
#include "VarList.h"
#include "Archive.h"
class CIniConfig;
class CXmlConfig;
class ILogicModule;

//针对IKernel 做了特殊写法 这里是位了隐藏 引擎内部的启动机制 
//引擎层 要对逻辑层做到 能不暴露 就不暴露

class IKernel {
public:
    //配置
    virtual const char * GetPath() const = 0;
    virtual const char * GetServerType() const = 0;
    virtual bool GetIniConfig(const char * pStrPath/*相对与引擎执行文件的路径*/, CIniConfig & iniconfig) const = 0;
    virtual bool GetXmlConfig(const char * pStrPath/*相对与引擎执行文件的路径*/, CXmlConfig & xmlconfig) const = 0;

    //逻辑模块之间
    virtual ILogicModule * FindModule(const char * pModuleName) const = 0;
    
    //注册连接与玩家对象的关联
//    virtual bool Register(const UI32 nPeerID, const CIdentity &) = 0;

    //注册回调
    virtual bool AddMsgSOCKETCALL(const char * pPeerType, const UI32 nMsgId, const SOCKETCALL pFun) const = 0;
//    virtual bool AddMsgSOCKETCALL(const char * pPeerType, const UI32 nMsgId, const OBJCALL pFun) const = 0; //玩家对象
    virtual bool AddKernelEventSOCKETCALL(const char * pPeerType, const UI32 nEventId, const SOCKETCALL pFun) const = 0;

    //消息操作
    virtual bool SendMsg(const UI32 nPeerID, const IArchive & msg) const = 0; //发送消息 最好都用这条 因为这条消息会少一次内存copy操作 性能要高一些 
//    virtual bool SendMsg(const CIdentity player, const IArchive & msg) const = 0; //发送消息 最好都用这条 因为这条消息会少一次内存copy操作 性能要高一些  
    
    virtual bool BroadCastByPeerType(const char * pPeerType, const IArchive & msg, const IVarList & blacklist = VarList() ) const = 0;//广播消息 最好都用这条 因为这条消息会少一次内存copy操作 性能要高一些
    
    virtual bool SendMsg(const UI32 nPeerID, const IVarList & msg) const = 0;
//    virtual bool SendMsg(const CIdentity player, const IVarList & msg) const = 0;
    
    virtual bool BroadCastByPeerType(const char * pPeerType, const IVarList & msg, const IVarList & blacklist = VarList() ) const = 0;
    virtual bool Close(const UI32 nPeerID) const = 0; //会在当前发送缓冲区的数据全部发送完之后关掉这条连接，并且调用该方法后该条连接不回在接受任何数据.
};

#endif //_KERNEL_H_
