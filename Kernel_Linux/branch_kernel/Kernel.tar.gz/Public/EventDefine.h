/* 
 * File:   EventDefine.h
 * Author: traveler
 *
 * Created on December 17, 2012, 8:41 PM
 */

#ifndef EVENTDEFINE_H
#define	EVENTDEFINE_H

enum KERNEL_EVENT{
    /*
     * 网络模块的回调
     */
    /* 主动连接成功 args: 
     * 0 UI32 nEventid=KERNEL_EVENT_CONNECT_SUCCESS 
     * 1 const char * pStrPeerType
     * 2 UI16 nSocket
     */
    KERNEL_EVENT_CONNECT_SUCCESS = 10000,
    
    /* 新的连接进来 args:
     * 0 UI32 nEventid = KERNEL_EVENT_NEW_CONNECTTION
     * 1 const char * pStrPeerType
     * 2 UI16 nSocket
     */
    KERNEL_EVENT_NEW_CONNECTION = 10001
};

#endif	/* EVENTDEFINE_H */
