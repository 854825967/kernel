#ifndef CALLBACK_H
#define CALLBACK_H

#include "ComDefine.h"

#include <map>
#include <vector>
#include <algorithm>
using namespace std;

template<typename T>
class CallBack {
public:

    CallBack() {
        m_mapContainer.clear();
    }

    ~CallBack() {
        typename map< T, vector< SOCKETCALL > * >::iterator itor = m_mapContainer.begin();
        typename map< T, vector< SOCKETCALL > * >::iterator iEnd = m_mapContainer.end();

        while (itor != iEnd) {
            if (NULL != itor->second) {
                delete itor->second;
                itor->second = NULL;
            }
            itor++;
        }
    }

    bool AddCall(const T ID, const SOCKETCALL pFun) {
        typename map< T, vector< SOCKETCALL > * >::iterator iFind = m_mapContainer.find(ID);

        vector< SOCKETCALL > * pVct;

        if (iFind == m_mapContainer.end()) {
            pVct = NEW vector< SOCKETCALL >;
            m_mapContainer.insert(make_pair(ID, pVct));
        } else {
            pVct = iFind->second;
        }

        vector< SOCKETCALL >::iterator itor = std::find(pVct->begin(), pVct->end(), pFun);
        if (itor != pVct->end()) {
            Assert(false); //LOG_ERROR("This call is exist");
            return false;
        }

        pVct->push_back(pFun);
        return true;
    }

    bool ExecCallBack(const T nMsgId, const IKernel * pKernel, const UI32 nID_1, const UI32 nID_2, const IVarList & args) {
        typename map< T, vector< SOCKETCALL > * >::iterator iFind = m_mapContainer.find(nMsgId);

        if (iFind == m_mapContainer.end()) {
            Assert(false);//
            //LOG_ERROR("This call is not exist");
            return false;
        }

        vector< SOCKETCALL > * pVct = iFind->second;
        vector< SOCKETCALL >::iterator itor = pVct->begin();
        vector< SOCKETCALL >::iterator iEnd = pVct->end();

        while (itor != iEnd) {
            (*itor)(pKernel, nID_1, nID_2, args);
            itor++;
        }

        return true;
    }

private:
    map< T, vector< SOCKETCALL > * > m_mapContainer;
};
#endif  //MSGCALLBACK_H
