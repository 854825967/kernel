#ifndef COMDEFINE_H
#define COMDEFINE_H

/*
 * system define
 * __LINUX_32__
 * __LINUX_64__
 * __WIN_32__
 * __WIN_64__
 */
#define __LINUX_64__
#include <stdio.h>
#include <stdlib.h>
//#include <iostream>
//using namespace std;

#ifdef __WIN_32__
#include <winsock2.h>
#include <Windows.h> 
#include <shlwapi.h>
#include <Mswsock.h>
#include <time.h>
#include <assert.h>

#pragma comment( lib, "ws2_32.lib" )
#pragma comment(lib, "shlwapi.lib")
#endif //WIN32


//#include "MemoryPool.h"

#define LOG_ERROR(strLog) \
    printf(strLog); \
    printf("\n");

#define NAME_LENGTH 64
#define MAX_PORT 65535

inline void _AssertionFail(const char * strFile, int nLine) {
    ::fflush(stdout);
    ::fprintf(stderr, "\nAsssertion failed: file %s, line %d", strFile, nLine);
    ::fflush(stderr);
    ::abort();
}

#define LOG(log) void
    //(cout << "Kernel Log : " << endl << __FILE__ , << "    Line : " << __LINE__ << "    " << log;)

#if defined __LINUX_32__ || defined __LINUX_64__
#define _NORMAL_BLOCK 1
#endif //__LINUX_32__ || __LINUX_64__

#ifdef _DEBUG
#define NEW new //::new(__FILE__, __LINE__)
#define  Assert(p) ((p) ? (void)0 : (void)_AssertionFail(__FILE__, __LINE__))
#else
#define NEW new
#define  Assert(p) 
#endif    //_DEBUG

//#if defined __LINUX_64__  || defined __LINUX_32__
//#define RAND_MAX 0x7fff
//#endif

typedef unsigned char UI8, UI8_TYPE;
typedef unsigned short int UI16;
typedef unsigned int UI32, UI32_ID, UI32_INDEX;

typedef char I8;
typedef short int I16;
typedef int I32;

#if defined __LINUX_64__ || defined __WIN_64__
typedef unsigned long UI64;
typedef long I64;
#else
#if defined __LINUX_32__ || defined __WIN_32__ 
typedef unsigned long long UI64;
typedef long long I64;
#endif
#endif

#define HEAD 0
#define ERROR_ID (UI32)-1
#define ERROR_INDEX (UI32)-1
#define NEW_LISTEN (UI32)-1

//后期这里 按照需求来该 SOCKETCALL的定义
class IKernel;
class IVarList;
class IArchive;

enum {
    TYPE_UNKWON = 0,
    TYPE_BOOL,
    TYPE_INT,
    TYPE_INT64,
    TYPE_STRING,
    TYPE_WIDESTR,
    TYPE_DOUBLE,
    TYPE_OBJECT,
};

class CIdentity {
public:

    inline bool operator ==(const CIdentity & b) {
        return (nAgency == b.nAgency);
    }

    inline bool operator !=(const CIdentity & b) {
        return (nAgency != b.nAgency);
    }

    CIdentity & operator = (const CIdentity & a) {
        nAgency = a.nAgency;
        return *this;
    }

    inline bool operator > (const CIdentity & a) {
        return (nAgency > a.nAgency);
    }
    
    inline bool operator < (const CIdentity & a) {
        return (nAgency < a.nAgency);
    }
    
    inline bool IsNull() {
        return (0 == nAgency);
    }

protected:

    CIdentity() {
    }

public:

    union {

        struct {
            UI32 nIdent;
            UI32 nSerial;
        };

        UI64 nAgency;
    };
};

class CIdentity_INIT : public CIdentity {
public:
    CIdentity_INIT() {
        nAgency = 0;
    }

    CIdentity_INIT(UI64 val) {
        nAgency = val;
    }

    CIdentity_INIT(UI32 ident, UI32 serial) {
        nIdent = ident;
        nSerial = serial;
    }

    CIdentity_INIT & operator=(const CIdentity & src) {
        nAgency = src.nAgency;
        return *this;
    }
};

typedef I32(*SOCKETCALL)(const IKernel *, const UI32, const UI32, const IVarList &); //事件回调函数定义
typedef I32(*HEARTBEATFUN)(const IKernel *, const IVarList &);
typedef I32(*DEF_BEATFUN)(const IKernel *, const CIdentity &, const UI32 nBeatCount);

typedef I32(*OBJCALL)(const IKernel *, const CIdentity &, const CIdentity &, const IVarList &);

typedef struct _VarData {
    UI8 type;

    union {
        bool boolValue;
        I32 intValue;
        I64 int64Value;
        double doubleValue;
        UI32 strIndex;
        UI32 wstrIndex;
    };
} VarData;

inline void SetDataType(VarData & var, const UI32 type) {
    var.type = type;
}

inline bool SetDataValue(VarData & var, const bool bValue) {
    if (var.type != TYPE_BOOL) {
        return false;
    }

    var.boolValue = bValue;
    return true;
}

inline bool SetDataValue(VarData & var, const I32 nValue) {
    if (var.type != TYPE_INT) {
        return false;
    }

    var.intValue = nValue;
    return true;
}

inline bool SetDataValue(VarData & var, const I64 n64Value) {
    if (var.type != TYPE_INT64) {
        return false;
    }

    var.int64Value = n64Value;
    return true;
}

inline bool SetDataValue(VarData & var, const double dbValue) {
    if (var.type != TYPE_DOUBLE) {
        return false;
    }

    var.doubleValue = dbValue;
    return true;
}

inline bool SetDataValue(VarData & var, const CIdentity & obj) {
    if (var.type != TYPE_OBJECT) {
        Assert(false);
        return false;
    }
    
    var.int64Value = obj.nAgency;
    return true;
}

inline bool SetDataString(VarData & var, const I32 nStrPos) {
    if (var.type != TYPE_STRING) {
        return false;
    }

    var.strIndex = nStrPos;
    return true;
}

inline bool SetDataWideStr(VarData & var, const I32 nWideStrPos) {
    if (var.type != TYPE_WIDESTR) {
        return false;
    }

    var.wstrIndex = nWideStrPos;
    return true;
}

#endif  //COMDEFINE_H
