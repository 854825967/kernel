#ifndef _KERNEL_H_
#define _KERNEL_H_

#include "./Interface/IBase.h"
#include "../Public/IKernel.h"
//#include "./Interface/IConfigManage.h"
//#include "./Interface/ICallBackSystem.h"

class IConfigManage;
class ILogicManage;
class ICallBackSystem;
class INetSystem;
class IVarList;
class IArchive;

class Kernel : public IKernel, public IBase {
public:
    static IKernel * Employ();
    virtual bool Bron();
    virtual bool Initialize();
    virtual bool Destroy();
    //配置
    virtual const char * GetPath() const;
    virtual const char * GetServerType() const;
    
    //功能接口
    virtual bool GetIniConfig(const char * pStrPath/*相对与引擎执行文件的路径*/, CIniConfig & iniconfig) const;
    virtual bool GetXmlConfig(const char * pStrPath/*相对与引擎执行文件的路径*/, CXmlConfig & xmlconfig) const;
    
    //逻辑模块之间
    virtual ILogicModule * FindModule(const char * pModuleName) const;
    
    //注册回调
    virtual bool AddMsgSOCKETCALL(const char * pPeerType, const UI32 nMsgId, const SOCKETCALL pFun) const;
    virtual bool AddKernelEventSOCKETCALL(const char * pPeerType, const UI32 nEventId, const SOCKETCALL pFun) const;
    
    virtual bool SendMsg(const UI32 nPeerID, const IArchive & msg) const; //发送消息 最好都用这条 因为这条消息会少一次内存copy操作 性能要高一些    
    virtual bool BroadCastByPeerType(const char * pPeerType, const IArchive & msg, const IVarList & blacklist = VarList() ) const;//广播消息 最好都用这条 因为这条消息会少一次内存copy操作 性能要高一些
    virtual bool SendMsg(const UI32 nPeerID, const IVarList & msg) const;
    virtual bool BroadCastByPeerType(const char * pPeerType, const IVarList & msg, const IVarList & blacklist = VarList() ) const;
    virtual bool Close(const UI32 nPeerID) const; //会在当前发送缓冲区的数据全部发送完之后关掉这条连接，并且调用该方法后该条连接不回在接受任何数据.
private:
    Kernel();
private:
    static Kernel * m_pSelf;
    static IConfigManage * m_pConfigManage;
    static ICallBackSystem * m_pCallBackSystem;
    static ILogicManage * m_pLogicManage;
    static INetSystem * m_pNetSystem;
};

#endif //_KERNEL_H_

