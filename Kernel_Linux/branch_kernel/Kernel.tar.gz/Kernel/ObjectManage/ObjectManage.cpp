/* 
 * File:   ObjectManage.cpp
 * Author: traveler
 * 
 * Created on December 26, 2012, 2:12 PM
 */

#include "ObjectManage.h"

IObjectManage * ObjectManage::m_pSelf = NULL;

ObjectManage::ObjectManage() {

}

ObjectManage::~ObjectManage() {

}

IObjectManage * ObjectManage::Employ() {
    if (NULL == m_pSelf) {
        m_pSelf = NEW ObjectManage;
        if (!m_pSelf->Bron()) {
            delete m_pSelf;
            m_pSelf = NULL;
        }
    }

    return m_pSelf;
}

bool ObjectManage::Bron() {
    return true;
}

bool ObjectManage::Initialize() {
    return true;
}

bool ObjectManage::Destroy() {
    return true;
}

bool ObjectManage::IsExsit(const CIdentity player) {
    unordered_map<UI64, UI32>::iterator itorplayer = m_mapkeyplayer.find(player.nAgency);
    if (itorplayer == m_mapkeyplayer.end()) {
        return false;
    }
    
    return true;
}

bool ObjectManage::Register(const UI32 nPeerID, const CIdentity player) {
    //    unordered_map<UI32, CIdentity> m_mapkeypeer;
    //    unordered_map<CIdentity, UI32> m_mapkeyplayer;

    unordered_map<UI32, UI64>::iterator itorpeer = m_mapkeypeer.find(nPeerID);
    unordered_map<UI64, UI32>::iterator itorplayer = m_mapkeyplayer.find(player.nAgency);

    if (itorpeer != m_mapkeypeer.end() || itorplayer != m_mapkeyplayer.end()) {
        Assert(false);
        return false;
    }

    m_mapkeypeer.insert(make_pair(nPeerID, player.nAgency));
    m_mapkeyplayer.insert(make_pair(player.nAgency, nPeerID));

    return true;
}

bool ObjectManage::Logoff(const CIdentity player) {
    unordered_map<UI64, UI32>::iterator itorplayer = m_mapkeyplayer.find(player.nAgency);
    if (itorplayer == m_mapkeyplayer.end()) {
        Assert(false);
        return false;
    }

    UI32 nPeerID = itorplayer->second;
    unordered_map<UI32, UI64>::iterator itorpeer = m_mapkeypeer.find(nPeerID);
    if (itorpeer == m_mapkeypeer.end()) {
        Assert(false);
        return false;
    }

    m_mapkeyplayer.erase(itorplayer);
    m_mapkeypeer.erase(itorpeer);

    return true;
}

bool ObjectManage::Logoff(const UI32 nPeerID) {
    unordered_map<UI32, UI64>::iterator itorpeer = m_mapkeypeer.find(nPeerID);
    if (itorpeer == m_mapkeypeer.end()) {
        Assert(false);
        return false;
    }

    UI64 nPlayerID = itorpeer->second;
    unordered_map<UI64, UI32>::iterator itorplayer = m_mapkeyplayer.find(nPlayerID);
    if (itorplayer == m_mapkeyplayer.end()) {
        Assert(false);
        return false;
    }

    m_mapkeyplayer.erase(itorplayer);
    m_mapkeypeer.erase(itorpeer);

    return true;
}

const UI32 ObjectManage::QueryPeerID(const CIdentity player) const {
    unordered_map<UI64, UI32>::const_iterator itorplayer = m_mapkeyplayer.find(player.nAgency);

    if (itorplayer == m_mapkeyplayer.end()) {
        Assert(false);
        return 0;
    }

    return itorplayer->second;
}

const CIdentity ObjectManage::QueryPlayer(const UI32 nPeerID) const {
    unordered_map<UI32, UI64>::const_iterator itorpeer = m_mapkeypeer.find(nPeerID);

    if (itorpeer == m_mapkeypeer.end()) {
        Assert(false);
        return CIdentity_INIT();
    }

    return CIdentity_INIT(itorpeer->second);
}
