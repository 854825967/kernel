/* 
 * File:   ObjectManage.h
 * Author: traveler
 *
 * Created on December 26, 2012, 2:12 PM
 */

#ifndef OBJECTMANAGE_H
#define	OBJECTMANAGE_H

#include "../Interface/IObjectManage.h"
#include "../../Public/ComDefine.h"
#include <string>
#include <tr1/unordered_map>
using namespace std;
using namespace tr1;

class ObjectManage : public IObjectManage {
public:
    static IObjectManage * Employ();
    ~ObjectManage();

    virtual bool Bron();
    virtual bool Initialize();
    virtual bool Destroy();

    virtual bool IsExsit(const CIdentity player);
    
    virtual bool Register(const UI32 nPeerID, const CIdentity player);
    virtual bool Logoff(const CIdentity player);
    virtual bool Logoff(const UI32 nPeerID);
    virtual const UI32 QueryPeerID(const CIdentity player) const;
    virtual const CIdentity QueryPlayer(const UI32 nPeerID) const;

private:
    ObjectManage();

private:
    static IObjectManage * m_pSelf;
    unordered_map<UI32, UI64> m_mapkeypeer;
    unordered_map<UI64, UI32> m_mapkeyplayer;

};

#endif	/* OBJECTMANAGE_H */

