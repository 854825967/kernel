#ifndef _ICALLBACKSYSTEM_H_
#define _ICALLBACKSYSTEM_H_

#include "../../Public/ComDefine.h"
#include "IBase.h"

class ICallBackSystem : public IBase {
public:
    //interface
    virtual bool AddMSGSOCKETCALL(const char * pPeerType, const UI32 nMsgId, const SOCKETCALL pFun) = 0;
    virtual bool ExMSGSOCKETCALL(const IKernel * pKernel, const char * pPeerType,
            const UI32 nMsgId, const UI32 nID, const IVarList & args) = 0;
    virtual bool AddKernelEventSOCKETCALL(const char * pPeerType, const UI32 nEventId, const SOCKETCALL pFun) = 0;
    virtual bool ExKernelEventSOCKETCALL(const IKernel * pKernel, const char * pPeerType,
            const UI32 nEventId, const UI32 nID, const IVarList & args) = 0;
};

#endif //_ICALLBACKSYSTEM_H_
