#ifndef _CALLBACKSYSTEM_H_
#define _CALLBACKSYSTEM_H_
#include "../Interface/ICallBackSystem.h"
#include "../../Public/CallBack.h"

#include <string>
#include <map>
using namespace std;

class CallBackSystem : public ICallBackSystem {
public:
    static ICallBackSystem * Employ();
    virtual bool Bron();
    virtual bool Initialize();
    virtual bool Destroy();
    ~CallBackSystem();
    //interface
    virtual bool AddMSGSOCKETCALL(const char * pPeerType, const UI32 nMsgId, const SOCKETCALL pFun);
    virtual bool ExMSGSOCKETCALL(const IKernel * pKernel, const char * pPeerType, 
        const UI32 nMsgId, const UI32 nID, const IVarList & args);
    virtual bool AddKernelEventSOCKETCALL(const char * pPeerType, const UI32 nEventId, const SOCKETCALL pFun);
    virtual bool ExKernelEventSOCKETCALL(const IKernel * pKernel, const char * pPeerType,
        const UI32 nMsgId, const UI32 nID, const IVarList & args);
private:
    CallBackSystem();

private:
    map<string, CallBack<UI32> * > m_msgcallcontainer;
    map<string, CallBack<UI32> * > m_eventcallcontainer;
    
    static ICallBackSystem * m_pSelf;
};

#endif //_CALLBACKSYSTEM_H_
