#include "CallBackSystem.h"
ICallBackSystem * CallBackSystem::m_pSelf = NULL;

ICallBackSystem * CallBackSystem::Employ() {
    if (NULL == m_pSelf) {
        m_pSelf = NEW CallBackSystem;
        if (!m_pSelf->Bron()) {
            delete m_pSelf;
            m_pSelf = NULL;
        }
    }

    return m_pSelf;
}

bool CallBackSystem::Bron() {
    m_msgcallcontainer.clear();
    return true;
}

bool CallBackSystem::Initialize() {

    return true;
}

bool CallBackSystem::Destroy() {

    if (NULL != m_pSelf) {
        delete m_pSelf;
        m_pSelf = NULL;
    }

    return true;
}

CallBackSystem::~CallBackSystem() {
    map<string, CallBack<UI32> * >::iterator itor = m_msgcallcontainer.begin();
    map<string, CallBack<UI32> * >::iterator iend = m_msgcallcontainer.end();
    while (itor != iend) {
        if (NULL != itor->second) {

            delete itor->second;
            itor->second = NULL;
        }
        itor++;
    }
}

bool CallBackSystem::AddMSGSOCKETCALL(const char * pPeerType, const UI32 nMsgId, const SOCKETCALL pFun) {
    map<string, CallBack<UI32> * >::iterator ifind = m_msgcallcontainer.find(pPeerType);

    if (ifind == m_msgcallcontainer.end()) {
        CallBack<UI32> * pContainer = NEW CallBack<UI32>;
        pContainer->AddCall(nMsgId, pFun);
        m_msgcallcontainer.insert(make_pair(pPeerType, pContainer));
        return true;
    }

    ifind->second->AddCall(nMsgId, pFun);

    return true;
}

bool CallBackSystem::ExMSGSOCKETCALL(const IKernel * pKernel, const char * pPeerType,
        const UI32 nMsgId, const UI32 nID, const IVarList & args) {
    map<string, CallBack<UI32> * >::iterator ifind = m_msgcallcontainer.find(pPeerType);

    if (ifind == m_msgcallcontainer.end()) {
        //Assert(ifind!=m_msgcallcontainer.end());
        return false;
    }

    ifind->second->ExecCallBack(nMsgId, pKernel, nID, nID, args);

    return true;
}

bool CallBackSystem::AddKernelEventSOCKETCALL(const char * pPeerType, const UI32 nEventId, const SOCKETCALL pFun) {
    map<string, CallBack<UI32> * >::iterator ifind = m_eventcallcontainer.find(pPeerType);

    if (ifind == m_eventcallcontainer.end()) {
        CallBack<UI32> * pContainer = NEW CallBack<UI32>;
        pContainer->AddCall(nEventId, pFun);
        m_eventcallcontainer.insert(make_pair(pPeerType, pContainer));
        //pContainer->AddCall(nEventId, pFun);
        return true;
    }

    ifind->second->AddCall(nEventId, pFun);

    return true;
}

bool CallBackSystem::ExKernelEventSOCKETCALL(const IKernel * pKernel, const char * pPeerType,
        const UI32 nMsgId, const UI32 nID, const IVarList & args) {
    map<string, CallBack<UI32> * >::iterator ifind = m_eventcallcontainer.find(pPeerType);

    if (ifind == m_eventcallcontainer.end()) {
        //Assert(ifind!=m_eventcallcontainer.end());
        return false;
    }

    ifind->second->ExecCallBack(nMsgId, pKernel, nID, nID, args);

    return true;
}

CallBackSystem::CallBackSystem() {

}