#include "Kernel.h"
#include "../Public/Tools.h"
#include "../Public/Archive.h"
#include "../Public/CXmlConfig.h"
#include "../Public/CIniConfig.h"
#include "./Config/ConfigManage.h"
#include "./CallBackSystem/CallBackSystem.h"
#include "LogicManage/LogicManage.h"
#include "NetSystem/NetSystem.h"


Kernel * Kernel::m_pSelf = NULL;
IConfigManage * Kernel::m_pConfigManage = NULL;
ICallBackSystem * Kernel::m_pCallBackSystem = NULL;
ILogicManage * Kernel::m_pLogicManage = NULL;
INetSystem * Kernel::m_pNetSystem = NULL;

Kernel::Kernel() {

}

IKernel * Kernel::Employ() {
    if (NULL == m_pSelf) {
        m_pSelf = NEW Kernel;
        if (!m_pSelf->Bron()) {
            Assert(false);
            delete m_pSelf;
            m_pSelf = NULL;
        }
    }

    return m_pSelf;
}

bool Kernel::Bron() {
    return true;
}

bool Kernel::Initialize() {
    if (NULL == (m_pConfigManage = ConfigManage::Employ()) ||
            NULL == (m_pCallBackSystem = CallBackSystem::Employ()) ||
            NULL == (m_pLogicManage = LogicManage::Employ()) ||
            NULL == (m_pNetSystem = NetSystem::Employ())) {

        Assert(false);
        return false;
    }

    return true;
}

bool Kernel::Destroy() {
    return true;
}

//配置

const char * Kernel::GetPath() const {
    return GetAppPath();
}

const char * Kernel::GetServerType() const {
    const CIniConfig * pconfig = m_pConfigManage->GetConfig(KERNEL_CONFIG_BASE_INI);
    const char * pStrType = pconfig->GetStringConfig("Base", "Type");
    if ("" == string(pStrType)) {
        Assert(false);
        return NULL;
    }

    return pStrType;
}

bool Kernel::GetIniConfig(const char * pStrPath, CIniConfig & iniconfig) const {
    char FilePath[256];
    memset(FilePath, 0, 256);
    snprintf(FilePath, 256, "%s/./%s", GetAppPath(), pStrPath);

    return iniconfig.LoadConfig(FilePath);
}

bool Kernel::GetXmlConfig(const char * pStrPath/*相对与引擎执行文件的路径*/, CXmlConfig & xmlconfig) const {
    return true;
}

//逻辑模块之间

ILogicModule * Kernel::FindModule(const char * pModuleName) const {
    return m_pLogicManage->FindModule(pModuleName);
}

//注册回调

bool Kernel::AddMsgSOCKETCALL(const char * pPeerType, const UI32 nMsgId, const SOCKETCALL pFun) const {
    m_pCallBackSystem->AddMSGSOCKETCALL(pPeerType, nMsgId, pFun);
    return true;
}

bool Kernel::AddKernelEventSOCKETCALL(const char * pPeerType, const UI32 nEventId, const SOCKETCALL pFun) const {
    m_pCallBackSystem->AddKernelEventSOCKETCALL(pPeerType, nEventId, pFun);
    return true;
}

bool Kernel::SendMsg(const UI32 nPeerID, const IArchive & msg) const {

    return m_pNetSystem->Send(nPeerID, msg);
}

bool Kernel::BroadCastByPeerType(const char* pPeerType, const IArchive & msg, const IVarList & blacklist) const {
    return m_pNetSystem->BroadCast(pPeerType, msg, blacklist);
}

bool Kernel::SendMsg(const UI32 nPeerID, const IVarList & msg) const {
    UI32 nCount = msg.Count();
    Archive achmsg;
    for (UI32 i = 0; i < nCount; i++) {
        switch (msg.Type(i)) {
            case TYPE_INT:
                achmsg << msg.GetInt(i);
                break;
            case TYPE_INT64:
                achmsg << msg.GetInt64(i);
                break;
            case TYPE_STRING:
                achmsg << msg.GetString(i);
                break;
            case TYPE_WIDESTR:
                achmsg << msg.GetWideStr(i);
                break;
            case TYPE_DOUBLE:
                achmsg << msg.GetDouble(i);
                break;
            default:
            {
                Assert(false); //不知到是什么类型
                return false;
            }
        }
    }

    return m_pNetSystem->Send(nPeerID, achmsg);
}

bool Kernel::BroadCastByPeerType(const char* pPeerType, const IVarList& msg, const IVarList & blacklist) const {
    UI32 nCount = msg.Count();
    Archive achmsg;
    for (UI32 i = 0; i < nCount; i++) {
        switch (msg.Type(i)) {
            case TYPE_INT:
                achmsg << msg.GetInt(i);
                break;
            case TYPE_INT64:
                achmsg << msg.GetInt64(i);
                break;
            case TYPE_STRING:
                achmsg << msg.GetString(i);
                break;
            case TYPE_WIDESTR:
                achmsg << msg.GetWideStr(i);
                break;
            case TYPE_DOUBLE:
                achmsg << msg.GetDouble(i);
                break;
            default:
            {
                Assert(false); //不知到是什么类型
                return false;
            }
        }
    }
    
    return m_pNetSystem->BroadCast(pPeerType, achmsg, blacklist);
}

bool Kernel::Close(const UI32 nPeerID) const {
    return m_pNetSystem->Close(nPeerID);
}
