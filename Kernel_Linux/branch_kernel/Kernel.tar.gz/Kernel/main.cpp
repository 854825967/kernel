/* 
 * File:   main.cpp
 * Author: traveler
 *
 * Created on December 7, 2012, 4:13 PM
 */
#define KERNEL_PROCESS

//#include <cstdlib>
#include <iostream>
//#include <sys/time.h>
//#include "../Public/CHashMap.h"
//#include "NetSystem/NetSystem.h"
//#include "CallBackSystem/CallBackSystem.h"
//#include "../Public/VarList.h"
//#include "../Public/CIniConfig.h"
//#include "../Public/CXmlConfig.h"
//#include "Config/ConfigManage.h"
//#include "LogicManage/LogicManage.h"
//#include "Kernel.h"
using namespace std;
//#include "NetSystem/PeerManage.h"
//#include "../Public/Tools.h"
//#include "../Public/CIdentity.h"
//#include "../Public/Sheet.h"
#include "./ObjectManage/ObjectManage.h"
#include "../Public/Tools.h"

int main(int argc, char** argv) {
    
    UI64 timetick1 = GetCurrentTimeTick();
    unordered_map<UI32, string> test;
    for(UI32 i=0; i<10000000; i++) {
        test.insert(make_pair(i, "hello workdfjklsdfsfdsafdsafdsafsdafasdfsadfsadfasdfdsafdsafdsafdsafdsafas"));
    }
    
    UI64 timetick2 = GetCurrentTimeTick();
    cout << timetick2 - timetick1 << endl;
    timetick2 = GetCurrentTimeTick();
    unordered_map<UI32, string>::iterator itor = test.begin();
    unordered_map<UI32, string>::iterator iend = test.end();
    while(itor != iend) {
        string str = itor->second.c_str();
        itor++;
    }
    
    UI64 timetick3= GetCurrentTimeTick();
    cout << timetick3 -timetick2 << endl;
    
    //    CIdentity a = CIdentity_INIT(100);


    //    UI64 nTick1 = GetCurrentTimeTick();
    //    
    //    IConfigManage * pConfigManage = ConfigManage::Employ();
    //    pConfigManage->Initialize();
    //    ICallBackSystem * pCallBackSystem = CallBackSystem::Employ();
    //    pCallBackSystem->Initialize();
    //    Kernel * pKernel = (Kernel *)Kernel::Employ();
    //    pKernel->Initialize();
    //    ILogicManage * pLogicManage = LogicManage::Employ();
    //    pLogicManage->Initialize();
    //    INetSystem * pNetSystem = NetSystem::Employ();
    //    pNetSystem->Initialize();
    //    cout << "My Type : " << pKernel->GetServerType() << endl;
    //    UI64 nTick2 = GetCurrentTimeTick();
    //    
    //    cout << nTick2 - nTick1 << endl;
    //    
    //pNetSystem->MainLoop();

    return 0;
}
