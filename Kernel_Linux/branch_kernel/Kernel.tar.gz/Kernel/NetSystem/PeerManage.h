#ifndef _PEERMANAGE_H_
#define _PEERMANAGE_H_

#include "../../Public/ComDefine.h"
#include "PeerInfo.h"
#include <vector>
#include <map>
#include <algorithm>
#include "../../Public/CHashMap.h"
#include <string>
using namespace std;

#define MAX_PEER_COUNTS 4096

class PeerManage {
public:
    PeerManage();
    bool AddPeerType(const char * pPeerType);
    PeerInfo * NewPeer(const UI16 nSocket, const char * pPeerType = NULL);
    bool RecyclePeer(PeerInfo * & pPeerInfo);
    PeerInfo * FindPeerBySocket(const UI16 nSocket);

    inline bool IsExsitType(const char * pPeerType) {
        vector<string>::iterator iend = m_alltype.end();
        vector<string>::iterator ifind = find(m_alltype.begin(), iend, pPeerType);
        if (ifind == iend) {
            return false;
        }

        return true;
    }
    vector<PeerInfo *> * GetTypeOfPeers(const char * pPeerType);
private:
    //存储所有存在的类型
    vector<string> m_alltype;
    //分类型存储所有链接
    map<string, vector<PeerInfo *> > m_alllink;
    //端管理
    vector<PeerInfo *> m_recycle;
    //方便快速查找
    CHashmap<UI16, PeerInfo *> m_QuickPosition;
    UI16 m_current;
    PeerInfo m_peers[MAX_PEER_COUNTS];
};

#endif //_PEERMANAGE_H_
