#ifndef _NETSYSTEM_H_
#define _NETSYSTEM_H_

#include "../../Public/ComDefine.h"
#include "../../Public/VarList.h"
#include "../Interface/INetSystem.h"
#include "../../Public/IKernel.h"
#include "../CallBackSystem/CallBackSystem.h"
#include "./PeerInfo.h"
#include "PeerManage.h"
#include "../../Public/CIniConfig.h"
#include <sys/epoll.h>

#define MAX_FDS 512
#define LISTEN_QUENE 100
#define SEND_BLOCK_SIZE 512
#define EVENT_QUENE_SIZE 512
#define RECVBUF_SIZE 1024

enum {
    SOCK_FOR_ACCEPT = 0,
    SOCK_FOR_RECV ,
    SOCK_FOR_SEND,
    SOCK_FOR_CONNECT,
};

class IConfigManage;

class NetSystem : public INetSystem {
public:
    static INetSystem * Employ();
    virtual bool Bron();
    virtual bool Initialize();
    virtual bool Destroy();
    //interface
    virtual bool BroadCast(const char * pPeerType, const IArchive & msg, const IVarList & blacklist = VarList() );
    virtual bool Send(const UI32 nSocket, const IArchive & msg);
    virtual bool Connect(const char * remotetype, const char * pStrIp, const UI16 nPort);
    virtual bool Listen(const char * remotetype, const char * pStrIp, const UI16 nPort);
    virtual bool Close(const UI32 nPeerID);
    virtual bool MainLoop();
    virtual ~NetSystem();
private:
    NetSystem();
    bool Setnonblocking(int sock);
    
private:
    //声明epoll句柄
    int m_epfd;
    //声明epoll_event结构体的变量,ev用于注册事件,数组用于回传要处理的事件
    struct epoll_event m_events[EVENT_QUENE_SIZE];
    //IniConfig m_config;
    char m_localtype[64];
    PeerManage m_peermanage;
    
    static INetSystem * m_pSelf;
    //回调管理器
    static ICallBackSystem * m_pCallBackSystem;
    //引擎入口
    static IKernel * m_pKernel;
    //配置管理器
    static IConfigManage * m_pConfigManage;
    //配置
    //CIniConfig m_BaseConfig;
};

#endif //_NETSYSTEM_H_
