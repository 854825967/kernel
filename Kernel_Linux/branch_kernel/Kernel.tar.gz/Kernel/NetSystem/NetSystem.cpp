#include "NetSystem.h"
#include <sys/socket.h>
#include <sys/epoll.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <iostream>
#include "../../Public/Archive.h"
#include "../../Public/VarList.h"
#include "../Kernel.h"
#include "../Config/ConfigManage.h"
using namespace std;

INetSystem * NetSystem::m_pSelf = NULL;
ICallBackSystem * NetSystem::m_pCallBackSystem = NULL;
IKernel * NetSystem::m_pKernel = NULL;
IConfigManage * NetSystem::m_pConfigManage = NULL;

INetSystem * NetSystem::Employ() {
    if (NULL == m_pSelf) {
        m_pSelf = NEW NetSystem;
        if (!m_pSelf->Bron()) {
            Assert(false);
            delete m_pSelf;
            m_pSelf = NULL;
        }
    }

    return m_pSelf;
}

NetSystem::NetSystem() {

}

bool NetSystem::Bron() {
    m_epfd = epoll_create(MAX_FDS);
    memset(m_events, 0, sizeof (m_events));

    return true;
}

bool NetSystem::Initialize() {
    if (NULL == (m_pKernel = Kernel::Employ()) ||
            NULL == (m_pCallBackSystem = CallBackSystem::Employ()) ||
            NULL == (m_pConfigManage = ConfigManage::Employ())) {

        Assert(false);
        return false;
    }

    const CIniConfig * globlaconfig = m_pConfigManage->GetConfig(KERNEL_CONFIG_GLOBLA_INI);
    if (NULL == globlaconfig) {
        Assert(false);
        return false;
    }

    const char * pStrServerTypes = globlaconfig->GetStringConfig("Global", "ServerTypes");
    if ("" == string(pStrServerTypes)) {
        Assert(false);
        return false;
    }

    VarList types;
    SafeSplitString(pStrServerTypes, ";", types);
    UI32 nCount = types.Count();
    if (0 >= nCount) {
        Assert(0);
        return false;
    }

    for (UI32 i = 0; i < nCount; i++) {
        m_peermanage.AddPeerType(types.GetString(i));
    }

    const CIniConfig * baseconfig = m_pConfigManage->GetConfig(KERNEL_CONFIG_BASE_INI);
    if (NULL == baseconfig) {
        Assert(false);
        return false;
    }

    const char * pstartlisten = baseconfig->GetStringConfig("Base", "Listen");
    if ("" != string(pstartlisten)) {
        VarList lslist;
        SafeSplitString(pstartlisten, ";", lslist);
        nCount = lslist.Count();
        for (UI32 i = 0; i < nCount; i++) {
            VarList listeninfo;
            SafeSplitString(lslist.GetString(i), ",", listeninfo);
            if (listeninfo.Count() != 3) {
                Assert(false);
                return false;
            }

            Listen(listeninfo.GetString(0), listeninfo.GetString(1), StringAsInt(listeninfo.GetString(2)));
        }
    }

    const char * pstartconnects = baseconfig->GetStringConfig("Base", "Connect");
    if ("" != string(pstartconnects)) {
        VarList connects;
        SafeSplitString(pstartconnects, ";", connects);
        nCount = connects.Count();
        for (UI32 i = 0; i < nCount; i++) {
            VarList connectinfo;
            SafeSplitString(connects.GetString(i), ",", connectinfo);
            if (connectinfo.Count() != 3) {
                Assert(false);
                return false;
            }

            Connect(connectinfo.GetString(0), connectinfo.GetString(1), StringAsInt(connectinfo.GetString(2)));
        }
    }


    return true;
}

NetSystem::~NetSystem() {
    close(m_epfd);
}

bool NetSystem::Destroy() {

    return true;
}

bool NetSystem::Connect(const char * remotetype, const char * pStrIp, const UI16 nPort) {
    if (NULL == pStrIp ||
            !m_peermanage.IsExsitType(remotetype)) {
        Assert(false);
        return false;
    }
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in serveraddr;

    memset(&serveraddr, 0, sizeof (serveraddr));
    serveraddr.sin_family = AF_INET;
    inet_aton(pStrIp, &(serveraddr.sin_addr));
    serveraddr.sin_port = htons(nPort);

    /* connect to the server */
    int result = connect(sockfd, (struct sockaddr *) &serveraddr, sizeof (serveraddr));
    if (result == -1) {
        printf("connect failed ");
        int nError = errno;
        Assert(false);
        exit(1);
    }

    //把socket设置为非阻塞方式
    if (!Setnonblocking(sockfd)) {
        Assert(false);
        close(sockfd);
        exit(1);
    }

    PeerInfo * pPeerInfo = m_peermanage.NewPeer(sockfd, remotetype);
    struct epoll_event ev;
    ev.data.ptr = pPeerInfo;
    ev.events = EPOLLIN | EPOLLOUT | EPOLLET;
    epoll_ctl(m_epfd, EPOLL_CTL_ADD, sockfd, &ev);
    //这里执行回调
    m_pCallBackSystem->ExKernelEventSOCKETCALL(m_pKernel,
            remotetype, KERNEL_EVENT_CONNECT_SUCCESS, sockfd, VarList());
}

bool NetSystem::BroadCast(const char * pPeerType, const IArchive & msg,
        const IVarList & blacklist) {
    if (NULL == pPeerType ||
            !m_peermanage.IsExsitType(pPeerType) ||
            0 == msg.Length()) {
        Assert(false);
        return false;
    }

    vector<PeerInfo *> * pVct = m_peermanage.GetTypeOfPeers(pPeerType);
    vector<PeerInfo *>::iterator itor = pVct->begin();
    const vector<PeerInfo *>::iterator iend = pVct->end();
    UI32 nCount = blacklist.Count();
    while (itor != iend) {
        for (UI32 i = 0; i < nCount; i++) {
            if (blacklist.Type(i) != TYPE_INT) {
                Assert(false);
                continue;
            }

            if ((*itor)->m_socket == blacklist.GetInt(i)) {
                continue;
            }
        }

        (*itor)->m_sendstream.WriteBuff(msg.GetStream(), msg.Length());
        itor++;
    }

    return true;
}

bool NetSystem::Send(const UI32 nSocket, const IArchive & msg) {
    if (nSocket >= 65335) { //如何控制这个端口的范围
        Assert(false);
        return false;
    }

    PeerInfo * pPeerInfo = m_peermanage.FindPeerBySocket(nSocket);
    if (NULL == pPeerInfo) {
        Assert(false);
        return false;
    }

    pPeerInfo->m_sendstream.WriteBuff(msg.GetStream(), msg.Length());

    return true;
}

bool NetSystem::Listen(const char * remotetype, const char* pStrIp, const UI16 nPort) {
    if (NULL == remotetype ||
            !m_peermanage.IsExsitType(remotetype) ||
            NULL == pStrIp ||
            nPort < 0) {
        Assert(false);
        return false;
    }

    //listen
    int listenfd;
    if (-1 == (listenfd = socket(AF_INET, SOCK_STREAM, 0))) {
        Assert(false);
        return false;
    }

    //把socket设置为非阻塞方式
    if (!Setnonblocking(listenfd)) {
        Assert(false);
        return false;
    }

    LinkInfo * pLinkInfo = m_peermanage.NewPeer(listenfd);
    pLinkInfo->SetRemoteType(remotetype);
    pLinkInfo->m_funtype = SOCK_FOR_ACCEPT;
    pLinkInfo->m_socket = listenfd;

    struct sockaddr_in serveraddr;
    memset(&serveraddr, 0, sizeof (serveraddr));
    serveraddr.sin_family = AF_INET;
    inet_aton(pStrIp, &(serveraddr.sin_addr));
    serveraddr.sin_port = htons(nPort);

    if (-1 == bind(listenfd, (sockaddr *) & serveraddr, sizeof (serveraddr)) ||
            -1 == (listen(listenfd, LISTEN_QUENE))) {
        Assert(false);
        return false;
    }

    struct epoll_event ev;
    ev.data.ptr = pLinkInfo;
    ev.events = EPOLLIN | EPOLLET;
    epoll_ctl(m_epfd, EPOLL_CTL_ADD, listenfd, &ev);

    return true;
}

bool NetSystem::MainLoop() {
    int nfds = 0;
    while (true) {
        //等待epoll事件的发生
        nfds = epoll_wait(m_epfd, m_events, EVENT_QUENE_SIZE, 10);
        //处理所发生的所有事件
        struct sockaddr_in clientaddr;
        socklen_t socklen;

        for (int i = 0; i < nfds; ++i) {
            PeerInfo * pPeerInfo = (PeerInfo *) (m_events[i].data.ptr);
            if (NULL == pPeerInfo) {
                Assert(false);
                continue;
            }
            if (pPeerInfo->m_funtype == SOCK_FOR_ACCEPT) {
                while (true) {
                    //如果新监测到一个SOCKET用户连接到了绑定的SOCKET端口，建立新的连接。
                    int connfd = accept(pPeerInfo->m_socket, (sockaddr *) & clientaddr, &socklen);
                    if (connfd < 0) {
                        break;
                    }
                    //把socket设置为非阻塞方式
                    if (!Setnonblocking(connfd)) {
                        Assert(false);
                        close(connfd);
                        break;
                    }

                    PeerInfo * pNewPeerInfo = m_peermanage.NewPeer(connfd, pPeerInfo->m_remotetype);
                    pNewPeerInfo->m_funtype = SOCK_FOR_RECV;
                    pNewPeerInfo->SetRemoteType(pPeerInfo->m_remotetype);
                    pNewPeerInfo->SetIp(inet_ntoa(clientaddr.sin_addr));
                    pNewPeerInfo->m_remoteport = clientaddr.sin_port;
                    //kernel event call
                    m_pCallBackSystem->ExKernelEventSOCKETCALL(m_pKernel, pPeerInfo->m_remotetype,
                            KERNEL_EVENT_NEW_CONNECTION, connfd, VarList());

                    struct epoll_event ev;
                    ev.data.ptr = pNewPeerInfo;
                    ev.events = EPOLLIN | EPOLLOUT | EPOLLET;
                    epoll_ctl(m_epfd, EPOLL_CTL_ADD, connfd, &ev);
                }
            } else if (m_events[i].events & EPOLLIN) {
                if (pPeerInfo->m_socket < 0) {
                    Assert(false);
                    break;
                }
                while (true) {
                    //如果是已经连接的用户，并且收到数据，那么进行读入。
                    char recvbuff[RECVBUF_SIZE];
                    memset(recvbuff, 0, RECVBUF_SIZE);
                    int nRecvLen = 0;

                    if ((nRecvLen = read(pPeerInfo->m_socket, recvbuff, RECVBUF_SIZE)) <= 0) {
                        if (EAGAIN == errno && -1 == nRecvLen) {
                            //表示数据已经取空 连接正常
                            break;
                        }
                        epoll_ctl(m_epfd, EPOLL_CTL_DEL, pPeerInfo->m_socket, NULL);
                        m_peermanage.RecyclePeer(pPeerInfo);
                        m_events[i].data.ptr = NULL;
                        break;
                    }

                    pPeerInfo->m_recvstream.WriteBuff(recvbuff, nRecvLen);
                    Archive msg;
                    VarList args;
                    while (pPeerInfo->m_recvstream.ReadArchive(msg)) {
                        if (msg.ToVarList(args)) {
                            if (args.Type(0) != TYPE_INT) {
                                epoll_ctl(m_epfd, EPOLL_CTL_DEL, pPeerInfo->m_socket, NULL);
                                m_peermanage.RecyclePeer(pPeerInfo);
                                m_events[i].data.ptr = NULL;
                                continue;
                            }

                            UI32 nMsgId = args.GetInt(0);
                            m_pCallBackSystem->ExMSGSOCKETCALL(m_pKernel, pPeerInfo->m_remotetype, nMsgId, pPeerInfo->m_socket, args);
                        }
                    }
                }

                if (NULL == m_events[i].data.ptr) {
                    break;
                }

                //设置用于写操作的文件描述符
                struct epoll_event ev;
                ev.data.ptr = pPeerInfo;
                ev.events = EPOLLIN | EPOLLOUT | EPOLLET;
                epoll_ctl(m_epfd, EPOLL_CTL_MOD, pPeerInfo->m_socket, &ev);
            } else if (m_events[i].events & EPOLLOUT) {
                //分块发送
                UI32 nLength = SEND_BLOCK_SIZE;
                struct epoll_event ev;
                ev.data.ptr = pPeerInfo;
                void * pBuff = NULL;
                while (true) {
                    //从发送缓冲区读出数据
                    pBuff = pPeerInfo->m_sendstream.ReadBuff(nLength);
                    //如果缓冲区中没有数据要发送了
                    if (0 == nLength) {
                        if (pPeerInfo->m_closeit) {
                            epoll_ctl(m_epfd, EPOLL_CTL_DEL, pPeerInfo->m_socket, NULL);
                            m_peermanage.RecyclePeer(pPeerInfo);
                            m_events[i].data.ptr = NULL;
                            break;
                        }
                        //设置用于注测的写操作事件
                        ev.events = EPOLLIN | EPOLLOUT | EPOLLET;
                        epoll_ctl(m_epfd, EPOLL_CTL_MOD, pPeerInfo->m_socket, &ev);
                        break;
                    }

                    int nSendSize = write(pPeerInfo->m_socket, pBuff, nLength);
                    if (-1 == nSendSize && NULL != m_events[i].data.ptr) {
                        epoll_ctl(m_epfd, EPOLL_CTL_DEL, pPeerInfo->m_socket, NULL);
                        m_peermanage.RecyclePeer(pPeerInfo);
                        m_events[i].data.ptr = NULL;
                        break;
                    }
                    //底层缓冲区满了或者sendstream里面的数据全发晚了
                    if (nSendSize < nLength) {
                        //回收没法送掉的但是已经从stream里取出来的数据
                        pPeerInfo->m_sendstream.Recover(SEND_BLOCK_SIZE - (nLength - nSendSize));
                        ev.events = EPOLLIN | EPOLLOUT | EPOLLET;
                        epoll_ctl(m_epfd, EPOLL_CTL_MOD, pPeerInfo->m_socket, &ev);
                        break;
                    }
                }
            }
        }
    }

    return false;
}

bool NetSystem::Setnonblocking(int sockfd) {
    if (fcntl(sockfd, F_SETFL, fcntl(sockfd, F_GETFD, 0) | O_NONBLOCK) == -1) {
        return false;
    }

    return true;
}

bool NetSystem::Close(const UI32 nPeerID) {

    PeerInfo * pPeer = m_peermanage.FindPeerBySocket(nPeerID);
    if (NULL == pPeer) {
        Assert(false);
        return false;
    }

    pPeer->m_closeit = true;

    return true;
}
