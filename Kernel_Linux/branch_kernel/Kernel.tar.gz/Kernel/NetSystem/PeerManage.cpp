#include "PeerManage.h"
#include <unistd.h>
using namespace std;

PeerManage::PeerManage() {
    m_current = 0;
}

PeerInfo * PeerManage::NewPeer(const UI16 nSocket, const char * pPeerType /*= NULL*/) {
    PeerInfo * pPeerInfo = NULL;

    if (pPeerType != NULL && !IsExsitType(pPeerType)) {
        //类型不存在
        Assert(false);
        return NULL;
    }

    if (!m_recycle.empty()) {
        pPeerInfo = m_recycle[0];
        m_recycle.erase(m_recycle.begin());
    } else {
        if (m_current + 1 >= MAX_PEER_COUNTS) {
            Assert(false);
            return NULL;
        }
        pPeerInfo = m_peers + m_current++;
    }

    if (pPeerType != NULL) {
        //分类型存储所有链接
        map<string, vector<PeerInfo *> >::iterator ifind = m_alllink.find(pPeerType);
        if (ifind == m_alllink.end()) {
            Assert(false);
            pPeerInfo->Reset();
            RecyclePeer(pPeerInfo);
            return NULL;
        }

        vector<PeerInfo *>::iterator itor = find(ifind->second.begin(), ifind->second.end(), pPeerInfo);
        if (itor != ifind->second.end()) {
            Assert(false); //该peerinfo已经被使用了 而且没被正确回收   说明代码有问题 要检查
            ifind->second.erase(itor);
            pPeerInfo->Reset();
            RecyclePeer(pPeerInfo);
            return NULL;
        } else {
            ifind->second.push_back(pPeerInfo);
        }

        pPeerInfo->SetRemoteType(pPeerType);
    }

    pPeerInfo->m_socket = nSocket;
    m_QuickPosition.Insert(nSocket, pPeerInfo);
    pPeerInfo->m_closeit = false;
    return pPeerInfo;
}

bool PeerManage::AddPeerType(const char * pPeerType) {
    if (NULL == pPeerType) {
        Assert(false);
        return false;
    }

    vector<string>::iterator ifindv = find(m_alltype.begin(), m_alltype.end(), pPeerType);
    map<string, vector<PeerInfo *> >::iterator ifindm = m_alllink.find(pPeerType);
    if (ifindm != m_alllink.end() || ifindv != m_alltype.end()) {
        Assert(false); //类型已经存在
        if (!(ifindm != m_alllink.end() && ifindv != m_alltype.end())) {
            Assert(false); //逻辑出问题了 
        }

        return false;
    }

    m_alltype.push_back(pPeerType);
    vector<PeerInfo *> vct;
    m_alllink.insert(make_pair(pPeerType, vct));

    return true;
}

bool PeerManage::RecyclePeer(PeerInfo * & pPeerInfo) {
    if(NULL == pPeerInfo) {
        Assert(false);
        return false;
    }
    //这里要多判断一次 如果该peerinfo是有类型的，要从对应类型的容器里剔除这个回收的链接
    vector<PeerInfo *>::iterator ifind = find(m_recycle.begin(), m_recycle.end(), pPeerInfo);
    if (ifind != m_recycle.end()) {
        Assert(false);
        //发现已经被回收了
        return false;
    }

    m_recycle.push_back(pPeerInfo);
    m_QuickPosition.Remove(pPeerInfo->m_socket);

    if (string(pPeerInfo->m_remotetype) != "") {
        //从分类容器里剔除被回收的端信息
        map<string, vector<PeerInfo *> >::iterator _ifind = m_alllink.find(pPeerInfo->m_remotetype);
        if (_ifind == m_alllink.end()) {
            Assert(false); //类型不存在
        } else {
            vector<PeerInfo *>::iterator itor = find(_ifind->second.begin(), _ifind->second.end(), pPeerInfo);
            if (itor == _ifind->second.end()) {
                Assert(false); //没有正确收容或者提前被剔除了
            } else {
                _ifind->second.erase(itor);
            }
        }
    }

    close(pPeerInfo->m_socket);
    pPeerInfo->m_recvstream.Clear();
    pPeerInfo->m_sendstream.Clear();
    pPeerInfo->Reset();
    pPeerInfo = NULL;
    return true;
}

vector<PeerInfo *> * PeerManage::GetTypeOfPeers(const char * pPeerType) {
    if (pPeerType != NULL && !IsExsitType(pPeerType)) {
        //类型不存在
        Assert(false);
        return NULL;
    }
    
    map<string, vector<PeerInfo *> >::iterator ifind = m_alllink.find(pPeerType);
    if( ifind == m_alllink.end() ) {
        Assert(false);
        return NULL;
    }
    
    return &(ifind->second);
}

PeerInfo * PeerManage::FindPeerBySocket(const UI16 nSocket) {
    return m_QuickPosition.Query(nSocket);
}


