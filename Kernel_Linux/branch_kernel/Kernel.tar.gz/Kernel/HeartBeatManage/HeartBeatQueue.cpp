/* 
 * File:   HeartBeatQueue.cpp
 * Author: traveler
 * 
 * Created on December 27, 2012, 6:30 PM
 */

#include "HeartBeatQueue.h"

HeartBeatQueue::HeartBeatQueue() {
}

HeartBeatQueue::HeartBeatQueue(const HeartBeatQueue& orig) {
}

HeartBeatQueue::~HeartBeatQueue() {
}

