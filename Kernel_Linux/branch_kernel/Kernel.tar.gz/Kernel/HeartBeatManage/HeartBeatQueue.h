/* 
 * File:   HeartBeatQueue.h
 * Author: traveler
 *
 * Created on December 27, 2012, 6:30 PM
 */

#ifndef HEARTBEATQUEUE_H
#define	HEARTBEATQUEUE_H

class HeartBeatQueue {
public:
    HeartBeatQueue();
    HeartBeatQueue(const HeartBeatQueue& orig);
    virtual ~HeartBeatQueue();
private:

};

#endif	/* HEARTBEATQUEUE_H */

