#ifndef HEARTBEATMANAGE_H
#define HEARTBEATMANAGE_H

#include "../Interface/IHeartBeatManage.h"
#include "../../Public/VarList.h"
#include "../../Public/ComDefine.h"
#include "../../Public/CHashMap.h"
#include <string>
using namespace std;

#define MAX_HEARTBEAT_COUNT 10240

struct heartbeat {
    UI64 nObjectID;
    bool isinuse;
    UI32 globlatimes;
    UI32 currenttimes;
    UI64 lasttick;
    HEARTBEATFUN pFun; 
    VarList args;
};

typedef struct heartbeat HeartBeat;

class HeartBeatManage : public IHeartBeatManage {
public:
    static IHeartBeatManage * Employ();
    virtual bool AddHeartBeat(const char * pStrName, const IVarList & args, const HEARTBEATFUN & pFun, const UI64 nInterval,const UI32 nCount);
    virtual bool DelHeartBeat(const char * pStrName);
    virtual bool FindHeartBeat(const char * pStrName);
    virtual bool ExHeartBeat(const UI64 nMaxExTime);
    
private:
    static IHeartBeatManage  * m_pSelf;
    CHashmap<string, HeartBeat *>;
    HeartBeat m_HeartBeatContainer[MAX_HEARTBEAT_COUNT];
    
};

#endif //HEARTBEATMANAGE_H
