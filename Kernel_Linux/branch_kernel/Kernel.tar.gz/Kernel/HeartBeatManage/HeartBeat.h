#ifndef HEARTBEAT_H
#define HEARTBEAT_H

#include "../../Public/ComDefine.h"
#include "../../Public/Tools.h"

class HeartBeat {
public:
    HeartBeat(const DEF_BEATFUN pBeatFun, const UI32 nBeatTime, const UI32 nBeatCount, const bool beatatonce = false);
    bool IsAlive();
    bool Beat(const IKernel * pKernel, const CIdentity & host, const UI64 nCurrentTimeTick);
private:
    bool m_Alive;
    DEF_BEATFUN m_pBeatFun;
    UI32 m_nBeatCount;
    UI32 m_nCurrentBeatCount;
    UI32 m_nBeatTime;
    UI64 m_nStartTime;
    UI64 m_nLastBeatTime;
};

#endif //HEARTBEAT_H
