#include "HeartBeat.h"

HeartBeat::HeartBeat(const DEF_BEATFUN pBeatFun, const UI32 nBeatTime, const UI32 nBeatCount, const bool beatatonce) {
    m_Alive = true;
    m_pBeatFun = pBeatFun;
    m_nBeatTime = nBeatTime;
    m_nBeatCount = nBeatCount;
    m_nStartTime = GetCurrentTimeTick();
    m_nCurrentBeatCount = 0;
    if (beatatonce) {
        m_nLastBeatTime = 0;
    } else {
        m_nLastBeatTime = GetCurrentTimeTick();
    }
}

bool HeartBeat::IsAlive() {
    return m_Alive;
}

bool HeartBeat::Beat(const IKernel * pKernel, const CIdentity & host, const UI64 nCurrentTimeTick) {
    if (!m_Alive) {
        Assert(false);
        return false;
    }

    if (m_nCurrentBeatCount >= m_nBeatCount) {
        m_Alive = false;
        Assert(false);
        return false;
    }

    if (0 == m_nLastBeatTime) {
        m_pBeatFun(pKernel, host, m_nCurrentBeatCount++);
        m_nLastBeatTime = nCurrentTimeTick;
    } else {
        if (nCurrentTimeTick - m_nLastBeatTime >= m_nBeatTime) {
            m_pBeatFun(pKernel, host, m_nCurrentBeatCount++);
            m_nLastBeatTime = nCurrentTimeTick;
        }
    }

    if (m_nCurrentBeatCount >= m_nBeatCount) {
        m_Alive = false;
    }

    return true;
}

