/* 
 * File:   LogicManage.cpp
 * Author: traveler
 * 
 * Created on December 18, 2012, 6:13 PM
 */

#include "LogicManage.h"
#include <dlfcn.h>
#include "../../Public/ComDefine.h"
#include "../Config/ConfigManage.h"
#include "../../Public/CIniConfig.h"
#include "../Kernel.h"
#include "../../Public/ILogicModule.h"
#include "../../Public/VarList.h"
#include "../../Public/Tools.h"

ILogicManage * LogicManage::m_pSelf = NULL;
IKernel * LogicManage::m_pKernel = NULL;
IConfigManage * LogicManage::m_pConfigManage = NULL;

ILogicManage * LogicManage::Employ() {
    if (NULL == m_pSelf) {
        m_pSelf = NEW LogicManage;
        if (!m_pSelf->Bron()) {
            Assert(false);
            delete m_pSelf;
            m_pSelf = NULL;
        }
    }

    return m_pSelf;
}

bool LogicManage::Bron() {
    return true;
}

bool LogicManage::Initialize() {
    if (NULL == (m_pKernel = Kernel::Employ()) ||
            NULL == (m_pConfigManage = ConfigManage::Employ())) {

        Assert(false);
        return false;
    }

    const CIniConfig * baseconfig = m_pConfigManage->GetConfig(KERNEL_CONFIG_BASE_INI);
    if (NULL == baseconfig) {
        Assert(false);
        return NULL;
    }
    const char * pStrDllPath = baseconfig->GetStringConfig("Modules", "Path");
    const char * pStrDllList = baseconfig->GetStringConfig("Modules", "DLL");

    if ("" == string(pStrDllPath) ||
            "" == string(pStrDllList)) {
        Assert(false);
        return false;
    }

    VarList dlls;
    SafeSplitString(pStrDllList, ";", dlls);
    UI32 ndllcount = dlls.Count();
    for (UI32 i = 0; i < ndllcount; i++) {
        char dllpath[256];
        memset(dllpath, 0, 256);
        snprintf(dllpath, 256, "%s/%s/%s", GetAppPath(), pStrDllPath, dlls.GetString(i));

        void * handle = dlopen(dllpath, RTLD_LAZY);
        if (NULL == handle) {
            Assert(handle);
            return false;
        }

        GetModuleFun function = (GetModuleFun) dlsym(handle, "GetLogicModule");
        if (NULL == function) {
            Assert(handle);
            return false;
        }

        ILogicModule * plogic = function();
        do {
            const char * pName = plogic->GetName();
            map<string, ILogicModule *>::iterator itor = m_mapModules.find(pName);
            if (itor != m_mapModules.end()) {
                Assert(false);
                return false;
            }

            m_mapModules.insert(make_pair(pName, plogic));
            plogic = plogic->GetNext();
        } while (plogic != NULL);

        map<string, ILogicModule *>::iterator itor = m_mapModules.begin();
        map<string, ILogicModule *>::iterator iend = m_mapModules.end();

        while (itor != iend) {
            if (NULL == itor->second) {
                Assert(false);
                return false;
            }
            itor->second->Initialize(m_pKernel);
            itor++;
        }

        while (itor != iend) {
            if (NULL == itor->second) {
                Assert(false);
                return false;
            }
            itor->second->DelayInitialize(m_pKernel);
            itor++;
        }
    }

    return true;
}

bool LogicManage::Destroy() {
    return true;
}

ILogicModule * LogicManage::FindModule(const char * pStrModuleName) {
    map<string, ILogicModule *>::iterator itor = m_mapModules.find(pStrModuleName);
    if (itor == m_mapModules.end()) {
        Assert(false);
        return false;
    }
    if (NULL == itor->second) {
        Assert(false);
        return false;
    }
    
    return itor->second;
}
