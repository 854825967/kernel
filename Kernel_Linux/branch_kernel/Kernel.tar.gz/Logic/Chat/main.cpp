#include "Chat.h"
#include "../../Public/ILogicModule.h"
GET_DLL_ENTRANCE
CREATE_MODULE(Chat)


