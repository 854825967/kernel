/* 
 * File:   Chat.h
 * Author: traveler
 *
 * Created on December 19, 2012, 2:27 PM
 */

#ifndef CHAT_H
#define	CHAT_H

#include "../../Public/ILogicModule.h"
#include "../../Public/EventDefine.h"
#include "../../Public/IKernel.h"
#include <iostream>
using namespace std;

enum {
    SERVER_MSG_TEST = 10000,
};

class Chat : public ILogicModule {
public:

    virtual bool Initialize(IKernel * pKernel) {
        cout << "Chat::Initialize()" << endl;
        pKernel->AddKernelEventSOCKETCALL("Gate", KERNEL_EVENT_CONNECT_SUCCESS, Chat::ConnectToGateSuccess); //代表连接Gate服务器成功 给的回调
        pKernel->AddKernelEventSOCKETCALL("Logic", KERNEL_EVENT_NEW_CONNECTION, Chat::NewConnectOfLogic); //代表有logic服务器成功连接进来  给的回调
        
        pKernel->AddMsgSOCKETCALL("Gate", SERVER_MSG_TEST, Chat::RecvMsgFromGate);
        pKernel->AddMsgSOCKETCALL("Logic", SERVER_MSG_TEST, Chat::RecvMsgFromLogic);
        return true;
    }

    virtual bool DelayInitialize(IKernel * pKernel) {

        return true;
    }

    virtual bool Destroy(IKernel * pKernel) {
        return true;
    }

private:

    static I32 NewConnectOfLogic(const IKernel * pKernel, UI32 nPeerID, UI32 notuse, const IVarList & args) {
        cout << "NewConnectFromLogicServer >> PeerID :" << nPeerID << endl;
        VarList msg;
        msg << SERVER_MSG_TEST << "hi,gemen";
        pKernel->SendMsg(nPeerID, msg);
        pKernel->BroadCastByPeerType("Logic", msg);
//        usleep(1000);
//        pKernel->SendMsg(nPeerID, msg);
//        pKernel->SendMsg(nPeerID, msg);
//        pKernel->SendMsg(nPeerID, msg);
        return 0;
    }

    static I32 ConnectToGateSuccess(const IKernel * pKernel, UI32 nPeerID, UI32 notuse, const IVarList & args) {
        cout << "ConnectToGateSuccess >> PeerID :" << nPeerID << endl;
        return 0;
    }
    
    static I32 RecvMsgFromGate(const IKernel * pKernel, UI32 nPeerID, UI32 notuse, const IVarList & args) {
        cout << "RecvMsgFromGate nPeerID :" << nPeerID << endl;
//        usleep(100);
//        VarList msg;
//        msg << SERVER_MSG_TEST << "hi,gemen";
//        pKernel->SendMsg(nPeerID, msg);
        return 0;
    }
    
    static I32 RecvMsgFromLogic(const IKernel * pKernel, UI32 nPeerID, UI32 notuse, const IVarList & args) {
        cout << "RecvMsgFromLogic nPeerID :" << nPeerID << endl;
//        VarList msg;
//        msg << SERVER_MSG_TEST << "hi,gemen";
//        pKernel->SendMsg(nPeerID, msg);
        return 0;
    }
};

#endif	/* CHAT_H */

