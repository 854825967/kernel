#!/bin/sh

if [ $# != 6 ] ; then 
echo "�����������������һ��Ϊ����������IP���ڶ���Ϊ����������IP��������Ϊ���ݿ�IP�����ĸ�����Ϊ�˿�ƫ��ֵ�����������Ϊcache������IP����6������Ϊ���ݿ�˿� �Կո�ֿ���" 
echo " ����: $0 192.168.168.15 222.73.93.73 192.168.168.22 2 192.168.168.15"
exit 1; 
fi 

cur_dir=`pwd $0`
dir=`pwd $0`
package=$dir/msserver.tar.gz
tar -xvf $package

echo "tar $package finish"

ip_lan=`echo $1`
ip_wan=`echo $2`
dbip=`echo $3`
memcached_ip=`echo $5`
dbport=`echo $6`

cp $cur_dir/configure/example_server.xml $cur_dir/configure/server.xml
cp $cur_dir/configure/example_dbserver.ini $cur_dir/configure/dbserver.ini
cp $cur_dir/configure/example_DBEngine.scp $cur_dir/configure/dbengine1.scp
cp $cur_dir/configure/example_DBEngine.scp $cur_dir/configure/dbengine2.scp
cp ./configure/example_memcached.xml ./configure/memcached.xml

dir=`pwd $0`
dir=`echo $dir | sed 's/\//\\\\\//g'`
echo "pwd is $dir"

#echo "s/\/home\/than\/msserver/$dir/g"
sed -i "s/\[msserver_directory\]/$dir/g" ./configure/server.xml
sed -i "s/\[server_lan_ip\]/$ip_lan/g" ./configure/server.xml
sed -i "s/\[server_wan_ip\]/$ip_wan/g" ./configure/server.xml
sed -i "s/\[db_server_ip\]/$ip_lan/g" ./configure/dbserver.ini
sed -i "s/\[db_ip\]/$dbip/g" ./configure/dbengine1.scp
sed -i "s/\[db_ip\]/$dbip/g" ./configure/dbengine2.scp
sed -i "s/\[db_port\]/$dbport/g" ./configure/dbengine1.scp
sed -i "s/\[db_port\]/$dbport/g" ./configure/dbengine2.scp
sed -i "s/\[memcached_ip\]/$memcached_ip/g" ./configure/memcached.xml

#change port server.xml
port=$[8888+$4]
sed -i "s/port=\"8888\"/port=\"$port\"/g" ./configure/server.xml
port=$[8000+$4]
sed -i "s/port=\"8000\"/port=\"$port\"/g" ./configure/server.xml
port=$[8100+$4]
sed -i "s/port=\"8100\"/port=\"$port\"/g" ./configure/server.xml
port=$[6789+$4]
sed -i "s/port=\"6789\"/port=\"$port\"/g" ./configure/server.xml
port=$[9100+$4]
sed -i "s/port=\"9100\"/port=\"$port\"/g" ./configure/server.xml
port=$[9500+$4]
sed -i "s/port=\"9500\"/port=\"$port\"/g" ./configure/server.xml
port=$[8500+$4]
sed -i "s/port=\"8500\"/port=\"$port\"/g" ./configure/server.xml
port=$[8900+$4]
sed -i "s/port=\"8900\"/port=\"$port\"/g" ./configure/server.xml
port=$[8901+$4]
sed -i "s/port=\"8901\"/port=\"$port\"/g" ./configure/server.xml

echo "configure server.xml complete!!"

#change port dbserver.ini
sed -i "s/DBServerPort = 8900/DBServerPort = $port/g" ./configure/dbserver.ini

log=`pwd $0`
log=$log/work/log
mkdir $log

core=$log/core
mkdir $core

echo "mkdir log and core ok"

